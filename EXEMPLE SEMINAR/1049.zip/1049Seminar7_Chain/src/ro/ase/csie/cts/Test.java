package ro.ase.csie.cts;

public class Test {
	
	public static void main(String[] args){
	ComandaOnline comanda1 = 
			new ComandaOnline(1200, "Gigel");
	ComandaOnline comanda2 = 
			new ComandaOnline(600, "Ionel");
	ComandaOnline comanda3 = 
			new ComandaOnline(200, "Ana");
	
	HandlerComandaMare hcmare = new HandlerComandaMare();
	HandlerComandaMica hcmica = new HandlerComandaMica();
	HandlerGeneric hc = new HandlerGeneric();
	hcmare.setNextHandler(hcmica);
	hcmica.setNextHandler(hc);
	
	hcmare.proceseazaComanda(comanda1);
	hcmare.proceseazaComanda(comanda2);
	hcmare.proceseazaComanda(comanda3);
	}
}
