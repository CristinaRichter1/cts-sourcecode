package ro.ase.csie.cts;

public class Test {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Banker bank1 = Banker.getBanker();
		Banker bank2 = Banker.getBanker();
		
		//bank2 = new Banker();
		
		SavingsAccount sa1 = (SavingsAccount)
				bank1.OpenAccount(AccountsType.SAVINGS);
		CurrentAccount ca1 = (CurrentAccount)
				bank2.OpenAccount(AccountsType.DEPOSIT);
		
		System.out.println(sa1.toString());
		System.out.println(ca1.toString());
		
		
		try {
			sa1.Deposit(1000);
			ca1.Withdraw(700);
			sa1.Transfer(ca1, 500);
			System.out.println(sa1.toString());
			System.out.println(ca1.toString());
			
		} catch (Exception e) {
			e.printStackTrace();
		}

		
	}

}
