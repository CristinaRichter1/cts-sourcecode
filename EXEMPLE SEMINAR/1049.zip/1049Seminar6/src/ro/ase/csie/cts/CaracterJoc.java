package ro.ase.csie.cts;

public abstract class CaracterJoc {
	protected String nume;
	
	//strategia privind arma folosita
	private StrategieArma arma;
	
	//model 3D serializat
	byte[] model = new byte[100];
	
	//operatii de baza
	public void merge(){
		System.out.println("Caracterul "+this.nume+" s-a miscat");
	}
	public void trage(){
		System.out.println("Caracterul "+this.nume+" a tras ");
		//apelare strategie
		if(this.arma!=null)
			this.arma.animatieArma();
	}
	
	public abstract void addChild(CaracterJoc caracter);
	public abstract void removeChild(CaracterJoc caracter);
	public abstract CaracterJoc getChild(int index);
	
	
	//setter pentru strategie
	public void setArma(StrategieArma arma){
		this.arma = arma;
	}
}
