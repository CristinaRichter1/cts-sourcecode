package ro.ase.csie.cts;

public class HandlerGeneric extends HandlerComanda{

	@Override
	public void proceseazaComanda(ComandaOnline comanda) {
		System.out.println("Trimis email catre "+ comanda.client);
	}

}
