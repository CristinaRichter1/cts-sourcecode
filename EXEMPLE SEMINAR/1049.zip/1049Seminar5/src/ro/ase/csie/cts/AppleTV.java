package ro.ase.csie.cts;

public class AppleTV implements  InterfataGadgetApple{

	@Override
	public String getDescriereApple() {
		return "Media box Apple - AppleTV";
	}


}
