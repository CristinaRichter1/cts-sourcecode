package ro.ase.csie.cts;

public class Test {
	public static void main(String[] args) {
		
		CaracterJoc comandantSuprem = new Comandant("Gigel");
		CaracterJoc soldat1 = new Soldat("Ion");
		Soldat soldat2 = new Soldat("Ionel");
		
		//test strategie
		soldat1.setArma(new ArmaClasica());
		soldat1.trage();
		//schimab strategia
		soldat1.setArma(new ArmaLaser());
		soldat1.trage();
		
		
		CaracterJoc comandantTrupa = new Comandant("Popescu");
		CaracterJoc soldat3 = new Soldat("Mihai");
		
		comandantSuprem.addChild(soldat1);
		comandantSuprem.addChild(comandantTrupa);
		comandantTrupa.addChild(soldat2);
		comandantTrupa.addChild(soldat3);
		
		comandantSuprem.getChild(1).getChild(1).merge();
		
		//generare harta cu soldati
		//fara flyweight
		CaracterJoc[] caractere = new CaracterJoc[5];
		LocatieHarta[] locatii = new LocatieHarta[5];
		
		caractere[0] = comandantSuprem;
		locatii[0] = new LocatieHarta(30, 1);
		caractere[1] = comandantTrupa;
		locatii[1] = new LocatieHarta(25, 10);
		caractere[2] = soldat1;
		locatii[2] = new LocatieHarta(15, 20);
		caractere[3] = soldat2;
		locatii[3] = new LocatieHarta(15, 25);
		
		
		//cu flyweight
		FlyweightFactoryCaracterJoc factory = 
				new FlyweightFactoryCaracterJoc();
		
		CaracterJoc[] caractere2 = new CaracterJoc[5];
		caractere2[0] = factory.getModelCaracter("comandant");
		caractere2[1] = factory.getModelCaracter("comandant");
		caractere2[2] = factory.getModelCaracter("soldat");
		caractere2[3] = factory.getModelCaracter("soldat");
		
		ConcreteFlyweightCaracterJoc[] locatiiClone = 
				new ConcreteFlyweightCaracterJoc[5];
		locatiiClone[0] = 
				new ConcreteFlyweightCaracterJoc("Gigel",new LocatieHarta(30, 1));
		locatiiClone[1] = 
				new ConcreteFlyweightCaracterJoc("Popescu",new LocatieHarta(25, 10));
	}

}
