package ro.ase.csie.cts;

public class IllegalTransferException extends Exception {
	public IllegalTransferException(String message) {
		super(message);
	}
}
