package ro.ase.csie.cts;

public class HandlerComandaMare 
	extends HandlerComanda{

	@Override
	public void proceseazaComanda(ComandaOnline comanda) {
		if(comanda.valoare > 1000)
		{
			System.out.println("Comanda lui "+comanda.client+" a fost procesata");
			comanda.esteLivrata = true;
			if(this.nextHandler!=null)
				this.nextHandler.proceseazaComanda(comanda);
		}
		else
			if(this.nextHandler!=null)
				this.nextHandler.proceseazaComanda(comanda);
	}

}
