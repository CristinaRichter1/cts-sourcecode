package ro.ase.csie.cts;

import java.util.HashMap;

public class FlyweightFactoryCaracterJoc {
	
	private HashMap<String,CaracterJoc> listaModeleCaractere = 
			new HashMap<>();
			
	
	public CaracterJoc getModelCaracter(String tipModel){
		
		CaracterJoc model = listaModeleCaractere.get(tipModel);
		if(model!=null)
			return model;
		else{
		if(tipModel.equals("soldat"))
			listaModeleCaractere.put("soldat",new Soldat("Clona0"));
		if(tipModel.equals("comandant"))
			listaModeleCaractere.put(
					"comandant",new Comandant("Clona0"));
		
		return listaModeleCaractere.get(tipModel);
		}
	}
}
