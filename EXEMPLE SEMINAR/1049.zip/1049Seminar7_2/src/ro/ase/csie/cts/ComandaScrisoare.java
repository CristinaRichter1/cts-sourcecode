package ro.ase.csie.cts;

public abstract class ComandaScrisoare {
	String adresaDestinatie;
	String adresaExpeditor;
	public abstract void trimite();
}
