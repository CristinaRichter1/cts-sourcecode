package ro.ase.csie.cts;

public class ComandaOnline {
	double valoare;
	String client;
	boolean esteLivrata;
	
	public ComandaOnline(double valoare, String client){
		this.valoare = valoare;
		this.client = client;
	}
}
