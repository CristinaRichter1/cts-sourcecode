package ro.ase.csie.cts;

public abstract class HandlerComanda {
	HandlerComanda nextHandler;
	
	public abstract void proceseazaComanda(
			ComandaOnline comanda);
	
	public void setNextHandler(HandlerComanda handler){
		this.nextHandler = handler;
	}
}
