package ro.ase.csie.cts;

public class LocatieHarta {
	public int X;
	public int Y;

	public LocatieHarta(int x, int y){
		this.X = x;
		this.Y = y;
	}

}
