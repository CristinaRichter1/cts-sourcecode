package ro.ase.csie.cts.seminar1;

public class ContDebit extends Cont {

	@Override
	public void setName(String name) {

	}

	@Override
	public void setActive(boolean state) {

	}
	
}
