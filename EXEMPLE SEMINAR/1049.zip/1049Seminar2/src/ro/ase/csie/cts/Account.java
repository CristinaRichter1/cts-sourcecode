package ro.ase.csie.cts;

public abstract class Account {
	public abstract void Transfer(
			Account destination, double amount) throws Exception;
	public abstract void Deposit(double amount);
	public abstract void Withdraw(double amount) throws Exception;
	public abstract double getBalance();
}
