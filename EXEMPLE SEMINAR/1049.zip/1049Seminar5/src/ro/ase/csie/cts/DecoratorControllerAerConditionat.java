package ro.ase.csie.cts;

public abstract class DecoratorControllerAerConditionat 
implements InterfataGadgetGoogle {
	protected InterfataGadgetGoogle controller;
	
	public DecoratorControllerAerConditionat(
			InterfataGadgetGoogle controller)
	{
		this.controller = controller;
	}
	
	public abstract void  inchideSiAerConditionat();
}
