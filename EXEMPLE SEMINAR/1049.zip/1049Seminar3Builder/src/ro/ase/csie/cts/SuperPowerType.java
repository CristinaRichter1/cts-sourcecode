package ro.ase.csie.cts;

public enum SuperPowerType {
	SPIDER_NET,LASER,SUPER_GLUE,FREEZE
}
