package ro.ase.csie.cts;

public class SuperHeroV0 {
	private final String name;	
	private final int age;
	private final String preferedColor;
	private final boolean isAble2Fly;
	private final boolean isAble2Run;
	private final boolean isVeryStrong;
	private final SuperPowerType superPower;
	
	public String getName() {
		return name;
	}

	public int getAge() {
		return age;
	}

	public String getPreferedColor() {
		return preferedColor;
	}

	public boolean isAble2Fly() {
		return isAble2Fly;
	}

	public boolean isAble2Run() {
		return isAble2Run;
	}

	public boolean isVeryStrong() {
		return isVeryStrong;
	}

	public SuperPowerType getSuperPower() {
		return superPower;
	}

	public SuperHeroV0(String name, int age, String preferedColor,
			boolean canFly, boolean canRun, boolean isStrong, 
			SuperPowerType superPower){
		this.name = name;
		this.age = age;
		this.preferedColor = preferedColor;
		this.isAble2Fly = canFly;
		this.isAble2Run = canRun;
		this.isVeryStrong = isStrong;
		this.superPower = superPower;
	}
	
	public SuperHeroV0 getSuperHero(String name, int age){
		boolean canFly = false;
		return new SuperHeroV0(name, age, "Blue",canFly,true,true,SuperPowerType.SUPER_GLUE);
	}
	
	//se vor adauga mai multe combinatii de getSuperHero() 
	//	care sa permita creare de obiecte initializare partial
	
}


