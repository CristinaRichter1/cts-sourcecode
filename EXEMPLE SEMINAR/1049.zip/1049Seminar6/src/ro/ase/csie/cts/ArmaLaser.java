package ro.ase.csie.cts;

public class ArmaLaser implements StrategieArma{

	@Override
	public void animatieArma() {
		System.out.println("--------------------------------------");
	}

}


