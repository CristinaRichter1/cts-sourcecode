package ro.ase.csie.cts;

public class Banker {
	
	private static Banker self = null;
	private static long accountId = 0;
	private final static String BankName = "ROBCR";
	private Banker(){}
	
	public static Banker getBanker(){
		if(Banker.self == null)
			Banker.self = new Banker();
		return Banker.self;
	}
	
	//factory method
	Account OpenAccount(AccountsType type){
		Account account = null;
		Banker.accountId++;
		String accountName = Banker.BankName+Banker.accountId;
		
		switch(type){
		case SAVINGS:
			account = new SavingsAccount(accountName);
			break;
		case DEPOSIT:
			account = new CurrentAccount(accountName);
			break;
		}
		return account;
	}
}

enum AccountsType {SAVINGS,DEPOSIT};




