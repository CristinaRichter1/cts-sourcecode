package ro.ase.csie.cts;

import java.util.ArrayList;

public class Comandant extends CaracterJoc{

	ArrayList<CaracterJoc> listaSoldati;
	
	@Override
	public void addChild(CaracterJoc caracter) {
		listaSoldati.add(caracter);
	}

	@Override
	public void removeChild(CaracterJoc caracter) {
		listaSoldati.remove(caracter);
	}

	@Override
	public CaracterJoc getChild(int index) {
		return listaSoldati.get(index);
	}
	
	public Comandant(String nume){
		listaSoldati = new ArrayList<>();
		this.nume = nume;
	}

}
