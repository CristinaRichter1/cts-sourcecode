package ro.ase.csie.cts;

//receiver

public class ServiciuPosta {
	
	private static ServiciuPosta singleton = null;
	
	String denumire;
	
	private ServiciuPosta(String denumire){
		this.denumire = denumire;
	}
	
	public static ServiciuPosta getServiciu(String denumire){
		if(singleton == null)
			singleton = new ServiciuPosta(denumire);
		return singleton;
	}
	
	//metoda tratare comanda de tip livrare normala
	public void proceseazaLivrareNormala(LivrareNormala scrisoare){
		System.out.println(
				"Scrisoarea a fost trimisa in regim normal catre "+
		scrisoare.adresaDestinatie + " prin serviciul "+this.denumire);
	}
	
	//metoda tratare comanda de tip livrare prioritara
	public void proceseazaLivrarePrioripost(LivrarePrioripost scrisoare){
		System.out.println(
				"Scrisoarea a fost trimisa in regim prioritar catre "+
		scrisoare.adresaDestinatie + " prin serviciul "+this.denumire);
	}
	
}
