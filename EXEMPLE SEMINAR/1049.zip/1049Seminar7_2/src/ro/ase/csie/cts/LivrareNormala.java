package ro.ase.csie.cts;

public class LivrareNormala extends ComandaScrisoare{
	
	//referinta catre serviciu
	ServiciuPosta posta;
	
	public LivrareNormala(
			String expeditor, String destinatar,ServiciuPosta posta){
		this.adresaExpeditor = expeditor;
		this.adresaDestinatie = destinatar;
		this.posta = posta;
	}
	@Override
	public void trimite() {
		posta.proceseazaLivrareNormala(this);
	}
	
}
