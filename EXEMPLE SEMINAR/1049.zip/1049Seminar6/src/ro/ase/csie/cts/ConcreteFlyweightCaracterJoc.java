package ro.ase.csie.cts;

public class ConcreteFlyweightCaracterJoc {
	public String nume;
	public LocatieHarta locatie;
	
	public ConcreteFlyweightCaracterJoc(
			String nume,LocatieHarta locatie){
		this.nume = nume;
		this.locatie = locatie;
	}
}
