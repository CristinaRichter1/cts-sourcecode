package ro.ase.csie.cts;

public interface InterfataGadgetApple {
	public String getDescriereApple();
}
