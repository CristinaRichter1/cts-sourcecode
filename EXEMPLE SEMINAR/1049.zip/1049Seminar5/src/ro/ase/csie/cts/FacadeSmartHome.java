package ro.ase.csie.cts;

public class FacadeSmartHome {
	//metoda facade pentru inchiderea casei
	public static void inchideCasa(int[] ferestre){
		ControllerGaze gaze = new ControllerGaze();
		gaze.inchide();
		
		ControllerFerestre controllerFerestre = 
				new ControllerFerestre();
		for(int fereastra : ferestre)
			controllerFerestre.inchideFereastra(fereastra);
		
		
		ControllerUsaIntrare usa = new ControllerUsaIntrare();
		usa.inchideUsa();
	}
}
