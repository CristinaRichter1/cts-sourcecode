package ro.ase.csie.cts;

public class HandlerComandaMica extends HandlerComanda{

	@Override
	public void proceseazaComanda(ComandaOnline comanda) {
		if(comanda.valoare < 1000 && comanda.valoare >= 500)
			System.out.println(
					"Comanda lui "+comanda.client + 
					" va fi procesata saptamana viitoare");
		if(this.nextHandler!=null)
			this.nextHandler.proceseazaComanda(comanda);
	}

}
