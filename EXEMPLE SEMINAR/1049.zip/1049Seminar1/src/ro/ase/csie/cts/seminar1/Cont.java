package ro.ase.csie.cts.seminar1;

public abstract class Cont {
	protected String name;
	protected boolean isActive;
	
	public String getName(){
		return this.name;
	}
	public boolean IsActive(){
		return this.isActive;
	}
	
	public abstract void setName(String name);
	public abstract void setActive(boolean state);
	
}
