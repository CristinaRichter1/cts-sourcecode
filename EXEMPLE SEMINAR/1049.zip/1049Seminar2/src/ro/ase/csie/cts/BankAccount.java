package ro.ase.csie.cts;

public abstract class BankAccount extends Account{
	protected String id;
	protected double balance;
	
	//supradefinire metoda din Account
	@Override
	public double getBalance(){
		return this.balance;
	}
	
	public BankAccount(String id){
		this.id = id;
	}
	
	@Override
	public void Deposit(double amount){
		this.balance+=amount;
	}
	
	@Override
	public String toString(){
		return "Account "+this.id+" - "+this.balance;
	}
}
