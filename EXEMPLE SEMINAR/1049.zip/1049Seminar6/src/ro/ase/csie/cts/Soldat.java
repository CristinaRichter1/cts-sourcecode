package ro.ase.csie.cts;

public class Soldat extends CaracterJoc{

	@Override
	public void addChild(CaracterJoc caracter) {
		throw new UnsupportedOperationException();
	}

	@Override
	public void removeChild(CaracterJoc caracter) {
		throw new UnsupportedOperationException();
	}

	@Override
	public CaracterJoc getChild(int index) {
		throw new UnsupportedOperationException();
	}
	
	public Soldat(String nume){
		this.nume = nume;
	}

}
