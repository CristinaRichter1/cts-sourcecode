package ro.ase.csie.cts;

public class SuperHero {
	private final String name;		//obligatoriu
	private final int age;				//obligatoriu
	private String preferedColor;	//optionale
	private boolean isAble2Fly;
	private boolean isAble2Run;
	private boolean isVeryStrong;
	private SuperPowerType superPower;
	
	public void setPreferedColor(String preferedColor) {
		this.preferedColor = preferedColor;
	}

	public void setAble2Fly(boolean isAble2Fly) {
		this.isAble2Fly = isAble2Fly;
	}

	public void setAble2Run(boolean isAble2Run) {
		this.isAble2Run = isAble2Run;
	}

	public void setVeryStrong(boolean isVeryStrong) {
		this.isVeryStrong = isVeryStrong;
	}

	public void setSuperPower(SuperPowerType superPower) {
		this.superPower = superPower;
	}

	public String getName() {
		return name;
	}

	public int getAge() {
		return age;
	}

	public String getPreferedColor() {
		return preferedColor;
	}

	public boolean isAble2Fly() {
		return isAble2Fly;
	}

	public boolean isAble2Run() {
		return isAble2Run;
	}

	public boolean isVeryStrong() {
		return isVeryStrong;
	}

	public SuperPowerType getSuperPower() {
		return superPower;
	}
	
	private SuperHero(String name, int age){
		this.name = name;
		this.age = age;
	}
	
	public static class SuperHeroBuilder{
		private SuperHero hero;
		
		public SuperHeroBuilder(String heroName, int heroAge){
			this.hero = new SuperHero(heroName, heroAge);
		}
		
		public SuperHeroBuilder isAble2Fly(boolean canFly){
			this.hero.setAble2Fly(canFly);
			return this;
		}
		
		public SuperHeroBuilder isAble2Run(boolean canRun){
			this.hero.setAble2Run(canRun);
			return this;
		}
		
		public SuperHeroBuilder isStrong(boolean isStrong){
			this.hero.setVeryStrong(isStrong);
			return this;
		}
		
		public SuperHeroBuilder setColor(String color){
			this.hero.setPreferedColor(color);
			return this;
		}
		
		public SuperHeroBuilder setSuperPower(
				SuperPowerType type){
			this.hero.setSuperPower(type);
			return this;
		}
		
		public SuperHero build(){
			return this.hero;
		}
	}
}


