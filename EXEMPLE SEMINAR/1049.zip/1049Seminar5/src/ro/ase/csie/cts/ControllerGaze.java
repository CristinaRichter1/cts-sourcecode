package ro.ase.csie.cts;

public class ControllerGaze implements InterfataGadgetGoogle {

	@Override
	public String getDescription() {
		return "Controller gaze de la Google";
	}
	
	public void inchide(){
		System.out.println("Gazele s-au inchis");
	}
	
	public void deschide(){
		System.out.println("Gazele s-au deschis");
	}

}
