package ro.ase.csie.cts.seminar1;

public class Test {

	public static void main(String[] args) {

	}

}
