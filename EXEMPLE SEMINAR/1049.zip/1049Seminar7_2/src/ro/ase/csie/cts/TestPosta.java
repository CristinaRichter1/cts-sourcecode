package ro.ase.csie.cts;

import java.util.ArrayList;

public class TestPosta {

	public static void main(String[] args) {
		Expeditor expeditor = new Expeditor("Gigel");
		ServiciuPosta posta = ServiciuPosta.getServiciu("Fan Courier");
		BackupExpeditor backup = new BackupExpeditor();
		
		expeditor.addComanda(
				new LivrareNormala(expeditor.nume, "CSIE", posta));
		expeditor.addComanda(
				new LivrareNormala(expeditor.nume, "ASE", posta));
		expeditor.addComanda(
				new LivrarePrioripost(expeditor.nume, "Adm. Financiara", posta));
		
		backup.addSalvare(expeditor.createMemento());
		
		expeditor.addComanda(
				new LivrareNormala(expeditor.nume, "CSIE2", posta));
		
		expeditor.setMemento(backup.getUltimaSalvare());
		
		ArrayList<ComandaScrisoare> scrisori = expeditor.getScrisori();
		
		for(ComandaScrisoare scrisoare : scrisori)
			scrisoare.trimite();
		
	}

}
