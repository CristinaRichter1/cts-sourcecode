package ro.ase.csie.cts;

public class DecoratorConcret 
		extends DecoratorControllerAerConditionat{

	public DecoratorConcret(InterfataGadgetGoogle controller) {
		super(controller);
	}

	@Override
	public String getDescription() {
		return this.controller.getDescription();
	}

	@Override
	public void inchideSiAerConditionat() {
		//referinta catre controller-ul de aer conditionat
		System.out.println("Aer conditiona oprit");
	}

}
