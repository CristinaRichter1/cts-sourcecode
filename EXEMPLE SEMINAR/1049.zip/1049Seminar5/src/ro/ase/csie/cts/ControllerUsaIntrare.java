package ro.ase.csie.cts;

public class ControllerUsaIntrare  implements InterfataGadgetGoogle{

	@Override
	public String getDescription() {
		return "Controller usa intrare de la Google";
	}
	
	public void inchideUsa(){
		System.out.println("Usa de la intrare s-a inchis");
	}
	
	public void deschideUsa(){
		System.out.println("Usa de la intrare s-a deschis");
	}

}
