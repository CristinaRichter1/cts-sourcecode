package ro.ase.csie.cts;

public class AdaptorApple2Google implements InterfataGadgetGoogle{

	private InterfataGadgetApple gadgetApple;
	
	public AdaptorApple2Google(InterfataGadgetApple gadget){
		this.gadgetApple = gadget;
	}
	
	@Override
	public String getDescription() {
		return gadgetApple.getDescriereApple();
	}

}
