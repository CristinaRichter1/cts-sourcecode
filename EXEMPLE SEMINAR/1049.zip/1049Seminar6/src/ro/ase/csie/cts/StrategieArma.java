package ro.ase.csie.cts;

public interface StrategieArma {
public abstract void animatieArma(); 
}
