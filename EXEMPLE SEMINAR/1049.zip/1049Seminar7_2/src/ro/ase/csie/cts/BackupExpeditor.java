package ro.ase.csie.cts;

import java.util.ArrayList;

//care taker

public class BackupExpeditor {
	ArrayList<MementoExpeditor> salvari;
	
	public BackupExpeditor(){
		this.salvari = new ArrayList<>();
	}
	
	public void addSalvare(MementoExpeditor salvare){
		this.salvari.add(salvare);
	}
	
	public MementoExpeditor getUltimaSalvare(){
		MementoExpeditor salvare = null;
		if(this.salvari.size() > 0){
			salvare = this.salvari.get(salvari.size()-1);
			this.salvari.remove(salvare);
		}
		return salvare;
	}
}
