package ro.ase.csie.cts;

import java.util.ArrayList;

//invoker

public class Expeditor {
	//colectie de comenzi
	ArrayList<ComandaScrisoare> comenzi;
	public String nume;
	
	public Expeditor(String nume){
		comenzi = new ArrayList<>();
		this.nume = nume;
	}
	
	public void addComanda(ComandaScrisoare scrisoare){
		this.comenzi.add(scrisoare);
	}
	
	public ArrayList<ComandaScrisoare> getScrisori(){
		return this.comenzi;
	}
	
	//metodele pentru memento
	public MementoExpeditor createMemento(){
		return new MementoExpeditor(this.comenzi);
	}

	public void setMemento(MementoExpeditor memento){
		this.comenzi = null;
		this.comenzi = 
				(ArrayList<ComandaScrisoare>)memento.getComenzi().clone();
	}
	
}
