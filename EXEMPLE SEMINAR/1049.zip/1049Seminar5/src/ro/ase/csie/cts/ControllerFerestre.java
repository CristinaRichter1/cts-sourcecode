package ro.ase.csie.cts;

public class ControllerFerestre implements InterfataGadgetGoogle{

	@Override
	public String getDescription() {
		return "Device Google: controller pentru ferestre";
	}
	
	public void inchideFereastra(int fereastra){
		System.out.println("Fereastra cu id-ul "+fereastra+" s-a inchis");
	}
	
	public void deschideFereastra(int fereastra){
		System.out.println("Fereastra cu id-ul "+fereastra+" s-a deschis");
	}

}
