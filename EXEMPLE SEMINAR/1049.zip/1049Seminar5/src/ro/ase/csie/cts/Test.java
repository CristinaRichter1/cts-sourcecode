package ro.ase.csie.cts;

import java.util.ArrayList;

public class Test {


	public static void main(String[] args) {
		//colectie de gadget-uri Google
		ArrayList<InterfataGadgetGoogle> listaGadgeturi = 
				new ArrayList<InterfataGadgetGoogle>();
		int [] listaFerestre = new int[]{1,2,3,4};
		
		ControllerFerestre ferestre = new ControllerFerestre();
		ControllerGaze gaze = new ControllerGaze();
		ControllerUsaIntrare usa = new ControllerUsaIntrare();
		
		listaGadgeturi.add(ferestre);
		listaGadgeturi.add(gaze);
		listaGadgeturi.add(usa);
		
		gaze.inchide();
		ferestre.inchideFereastra(listaFerestre[1]);
		usa.inchideUsa();
		
		//adaugare prin adaptor a unui device Apple
		AppleTV appleTV = new AppleTV();
		
		
		//definire adaptor
		AdaptorApple2Google adaptorAppleTV = 
				new AdaptorApple2Google(appleTV);
		
		listaGadgeturi.add(adaptorAppleTV);
		
		for(InterfataGadgetGoogle gadget : listaGadgeturi)
			System.out.println(gadget.getDescription());
		
		//testare facade
		FacadeSmartHome.inchideCasa(listaFerestre);
		
		//testare decorator
		ferestre.deschideFereastra(3);
		//cum fac ferestrele sa inchida si aerul conditionat
		DecoratorConcret decoratorFerestre  = 
				new DecoratorConcret(ferestre);
		decoratorFerestre.inchideSiAerConditionat();
		
		listaGadgeturi.add(decoratorFerestre);
		
		
		
		
	}

}
