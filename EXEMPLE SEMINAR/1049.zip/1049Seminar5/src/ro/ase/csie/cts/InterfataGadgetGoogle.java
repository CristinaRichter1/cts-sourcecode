package ro.ase.csie.cts;

public interface InterfataGadgetGoogle {
	public String getDescription();
}
