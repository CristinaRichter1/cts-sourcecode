package ro.ase.csie.cts;

import ro.ase.csie.cts.SuperHero.SuperHeroBuilder;

public class Test {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		SuperHeroV0 hero1 = 
				new SuperHeroV0("Spiderman", 26, 
						"Red", false, 
						false, true, 
						SuperPowerType.SPIDER_NET);
		
		SuperHero hero2 = new SuperHero.SuperHeroBuilder("Spiderman", 26)
		.setColor("Red")
		.setSuperPower(SuperPowerType.SPIDER_NET)
		.isStrong(true)
		.build();
	}

}
