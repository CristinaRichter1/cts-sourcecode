package ro.ase.csie.cts;

public class SavingsAccount extends BankAccount implements Profitable{
	
	public final static double MIN_BALANCE = 100;

	@Override
	public void Transfer(Account destination, double amount) throws Exception {
		if(destination == this)
			throw new IllegalTransferException("Same accounts!");
		if((this.balance-amount)<SavingsAccount.MIN_BALANCE)
			throw new InsufficientFundsException("No more money !");
		
		this.Withdraw(amount);
		destination.Deposit(amount);
	}

	@Override
	public void Withdraw(double amount) throws Exception {
		if((this.balance-amount)<SavingsAccount.MIN_BALANCE)
			throw new InsufficientFundsException("No more money !");
		this.balance-=amount;
	}

	@Override
	public void AddInterest(double interest) throws Exception {
		if(interest > 1.0)
			throw new Exception("Wrong interest");
		this.balance*=(1+interest);
	}
	
	public SavingsAccount(String id){
		super(id);
		this.balance = SavingsAccount.MIN_BALANCE;
	}

}
