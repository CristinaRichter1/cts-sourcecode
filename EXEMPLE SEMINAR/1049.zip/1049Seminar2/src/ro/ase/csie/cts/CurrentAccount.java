package ro.ase.csie.cts;

import org.omg.CosNaming.IstringHelper;

public class CurrentAccount extends BankAccount{
	
	public static final double MAX_CREDIT = 5000;
	
	@Override
	public void Transfer(Account destination, double amount) 
			throws Exception {
		if(destination instanceof CurrentAccount)
			throw new Exception("Transfer ilegal !");
		else
			if(this.balance < amount)
				throw new Exception("Fonduri insuficiente");
			else
			{
				this.Withdraw(amount);
				destination.Deposit(amount);
			}
	}

	@Override
	public void Withdraw(double amount) throws Exception {
		if(this.balance < amount)
			throw new Exception("Fonduri insuficiente!");
		else
			this.balance-=amount;
	}
	
	public CurrentAccount(String id){
		super(id);
		this.balance = CurrentAccount.MAX_CREDIT;
	}

}
