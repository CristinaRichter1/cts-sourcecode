package ro.ase.csie.cts;

import java.util.ArrayList;

import javax.print.attribute.standard.DateTimeAtCompleted;

public class MementoExpeditor {
	//gestioneaza starea expeditorului
	private ArrayList<ComandaScrisoare> comenzi;
	private long timestamp;
	
	public ArrayList<ComandaScrisoare> getComenzi(){
		return this.comenzi;
	}
	
	public MementoExpeditor(
			ArrayList<ComandaScrisoare> comenzi){
		this.comenzi = (ArrayList<ComandaScrisoare>)comenzi.clone();
		this.timestamp = System.currentTimeMillis();
	}

}
