package ro.ase.csie.cts;

public class LivrarePrioripost extends ComandaScrisoare{
	
	//referinta catre serviciu
	ServiciuPosta posta;
	
	public LivrarePrioripost(
			String expeditor, String destinatar,ServiciuPosta posta){
		this.adresaExpeditor = expeditor;
		this.adresaDestinatie = destinatar;
		this.posta = posta;
	}
	@Override
	public void trimite() {
		posta.proceseazaLivrarePrioripost(this);
	}
	
}
