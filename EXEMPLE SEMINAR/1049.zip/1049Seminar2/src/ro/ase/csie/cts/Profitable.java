package ro.ase.csie.cts;

public interface Profitable {
	public abstract void AddInterest(double interest) throws Exception;
}
